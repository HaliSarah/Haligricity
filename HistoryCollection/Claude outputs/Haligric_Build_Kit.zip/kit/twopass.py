"""
Title: Haligric two-pass builder
Author: Claude
Date: 2026-11-04
Modified By: Claude, 2026-11-10 (made portable for Mac)
Description: Runs the docx-to-PDF pipeline twice so the contents page carries real page
             numbers, then confirms headings did not move between passes.
Usage: python3 twopass.py sources/<name> <Name_master.pdf> [--new]
"""
import json, os, re, shutil, subprocess, sys
from pypdf import PdfReader

# WHY: Hali's library lives in one fixed place, so finished PDFs go straight there.
HISTORY = os.path.expanduser("~/Desktop/Websites/Haligricity/Hosted/HistoryCollection")

args = [a for a in sys.argv[1:] if a != "--new"]
is_new = "--new" in sys.argv
if len(args) != 2:
    raise SystemExit("Usage: python3 twopass.py sources/<name> <Name_master.pdf> [--new]")
folder, outname = args
# WHY: look for build.js next to this script so the kit works from any folder on any computer.
build = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build.js")
content = os.path.abspath(os.path.join(folder, "content.js"))

# WHY: on a Mac, LibreOffice installs soffice inside the app bundle, not on the PATH.
SOFFICE = shutil.which("soffice") or "/Applications/LibreOffice.app/Contents/MacOS/soffice"
if not os.path.exists(SOFFICE) and not shutil.which("soffice"):
    raise SystemExit("LibreOffice not found. Install it from libreoffice.org, then try again.")


def norm(text):
    # Line wraps and curly quotes differ between source and PDF, so compare a flattened form.
    text = text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    text = text.replace("-\n", "-")
    return re.sub(r"\s+", " ", text).lower().strip()


def render(tag, pages=None):
    # Each pass gets its own docx so a failed pass 2 never overwrites pass 1 output.
    docx = os.path.join(folder, f"{tag}.docx")
    cmd = ["node", build, content, docx] + ([pages] if pages else [])
    subprocess.run(cmd, check=True, capture_output=True)
    subprocess.run([SOFFICE, "--headless", "--convert-to", "pdf", "--outdir", folder, docx],
                   check=True, capture_output=True, timeout=180)
    return os.path.join(folder, f"{tag}.pdf")


def locate(pdf):
    reader = PdfReader(pdf)
    raw = [(p.extract_text() or "") for p in reader.pages]
    headings = subprocess.run(
        ["node", "-e", f"console.log(JSON.stringify(require({json.dumps(content)}).sections.map(s=>s.heading)))"],
        check=True, capture_output=True, text=True).stdout
    headings = json.loads(headings)
    pages = [[norm(l) for l in t.split("\n") if l.strip()] for t in raw]

    def hit(lines, key):
        # A heading must start a line and fill it, so body mentions of the same words are ignored.
        for i, line in enumerate(lines):
            joined = line
            for j in range(i, min(i + 4, len(lines))):
                if j > i:
                    joined = joined + " " + lines[j]
                if joined == key:
                    return True
                if not key.startswith(joined):
                    break
        return False

    # Contents pages hold dotted lines, so requiring an exact line match already skips them.
    found, cursor = {}, 1
    for h in headings:
        key = norm(h)
        for i in range(cursor, len(pages)):
            if hit(pages[i], key):
                found[h] = i + 1
                cursor = i
                break
        else:
            raise SystemExit(f"Heading not found: {h}")
    return found, len(pages)


p1 = render("pass1")
pages1, count1 = locate(p1)
pj = os.path.join(folder, "pages.json")
json.dump({k: str(v) for k, v in pages1.items()}, open(pj, "w"))
p2 = render("pass2", pj)
pages2, count2 = locate(p2)
bad = [h for h in pages1 if pages1[h] != pages2[h]]
if bad or count1 != count2:
    print("SHIFTED", bad, count1, count2)
# WHY: rebuilds overwrite the same-named file in HistoryCollection; --new sends brand-new
# traditions to HistoryCollection/new so they can be reviewed before going live.
dest_dir = os.path.join(HISTORY, "new") if is_new else HISTORY
if not os.path.isdir(HISTORY):
    dest_dir = folder  # WHY: fall back quietly when run on a computer without that folder
os.makedirs(dest_dir, exist_ok=True)
dest = os.path.join(dest_dir, outname)
shutil.copyfile(p2, dest)
os.replace(p2, os.path.join(folder, outname))  # WHY: keep a copy beside the source too
text = " ".join((p.extract_text() or "") for p in PdfReader(dest).pages)
print("Saved to", dest)
print(outname, "pages", count2, "words", len(text.split()), "sections", len(pages2), "shifts", len(bad))
