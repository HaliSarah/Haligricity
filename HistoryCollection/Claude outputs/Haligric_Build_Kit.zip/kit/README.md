# Haligric Build Kit

Builds a series PDF from a `content.js` file on your Mac. It adds the dot-leader contents page and real page numbers, uses Georgia, and leaves no footer on page 1. It costs no tokens.

## One-time setup

1. Install **Node.js** (LTS) from nodejs.org.
2. Install **LibreOffice** from libreoffice.org.
3. Open Terminal, `cd` into this folder, and run:

```
npm install
pip3 install pypdf
```

## Build a PDF

Each tradition's source lives in `sources/<name>/content.js`. Arctic, Buddhism, Tenrikyo and Cao Dai are already in there.

**Rebuild** (overwrites the same-named PDF in HistoryCollection):

```
python3 twopass.py sources/arctic Arctic_Inuit_master.pdf
```

**New tradition** (saves to HistoryCollection/new):

```
python3 twopass.py sources/buddhism Buddhism_master.pdf --new
```

It saves straight to `~/Desktop/Websites/Haligricity/Hosted/HistoryCollection` and keeps a copy beside the source. The last lines say where it saved, plus pages, words, sections and shifts. Shifts should be 0.

For a new tradition, make `sources/<name>/` and put its `content.js` in it. You can download it from the Research Check project.

## Editing content.js

- `titleLines`, `subtitle`, `blurb`: page 1
- `sections`: each has a `heading` and `paragraphs` (one string per paragraph)
- `closing`: the last lines, ending with "You are the current."

Wrap each paragraph in straight double quotes. If a paragraph needs a `"` inside it, write `\"`.

Check for typos before building:

```
node -e "require('./arctic/content.js')"
```

No output means it's fine.

## Common errors

- **"Heading not found"**: a heading is too long and wrapped onto two lines. Shorten it.
- **"LibreOffice not found"**: install LibreOffice to /Applications.
