/*
 * Title: Haligric Research Integration Series build script
 * Author: Haligricity / I.Q. Productionz project template
 * Date: 2026-08-28
 * Modified By: Claude, 2026-11-10 (made portable for Mac)
 * Description: Turns a content.js file into a formatted .docx. Run twice: once with
 *              placeholder page numbers, once with real ones from pages.json.
 * Usage: node build.js <content.js> <out.docx> [pages.json]
 */
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  TabStopType, LeaderType, Header, BorderStyle
} = require('docx'); // WHY: plain require so it finds the copy npm installs beside this script on any computer

const C = require(path.resolve(process.argv[2]));
const outPath = process.argv[3];
const pagenumsPath = process.argv[4];

// Pass 1 has no page map yet, so a missing file must fall back to the "00" placeholders.
let pagenums = {};
if (pagenumsPath && fs.existsSync(pagenumsPath)) {
  pagenums = JSON.parse(fs.readFileSync(pagenumsPath, 'utf8'));
}

const FONT = "Georgia";
const BLACK = "000000"; // Explicit black avoids LibreOffice's blue-heading bug.
const GRAY = "666666";

// Why a helper: every run needs the font and color set, or LibreOffice falls back to defaults.
const run = (text, opts = {}) => new TextRun({ text, font: FONT, color: BLACK, ...opts });

const center = (children, after) => new Paragraph({
  alignment: AlignmentType.CENTER, children, spacing: { after }
});

// The dot leader must be a tab stop; PositionalTab does not render in LibreOffice.
function tocEntry(title, page) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: 9360, leader: LeaderType.DOT }],
    children: [run(`${title}\t${page}`, { size: 22 })],
    spacing: { after: 110 }
  });
}

function heading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    keepNext: true, // Stops a heading stranding at the bottom of a page.
    children: [run(text, { bold: true, size: 32 })],
    spacing: { before: 300, after: 200 }
  });
}

function body(text) {
  return new Paragraph({
    children: [run(text, { size: 22 })],
    spacing: { after: 180 },
    alignment: AlignmentType.JUSTIFIED
  });
}

const header = new Header({
  children: [new Paragraph({
    children: [new TextRun({ text: `${C.tradition} | ${C.series}`, font: FONT, size: 16, color: GRAY })],
    border: { bottom: { color: "999999", style: BorderStyle.SINGLE, size: 4, space: 4 } },
    spacing: { after: 100 }
  })]
});

const page = { margin: { top: 720, bottom: 720, left: 900, right: 900 } };

// Title page sits in its own section so it carries no header or footer.
const titleSection = {
  properties: { page },
  children: [
    center([run(C.series, { italics: true, size: 24 })], 400),
    ...C.titleLines.map((l, i) => center([run(l, { bold: true, size: 120 })], i === C.titleLines.length - 1 ? 200 : 0)),
    center([run("A COMPLETE DEEP DIVE", { bold: true, size: 56 })], 300),
    center([run(C.subtitle, { italics: true, size: 28 })], 300),
    new Paragraph({ border: { bottom: { color: BLACK, style: BorderStyle.SINGLE, size: 6, space: 8 } }, spacing: { after: 300 } }),
    ...C.blurb.map(l => center([run(l, { italics: true, size: 24 })], 200))
  ]
};

const tocSection = {
  properties: { page },
  headers: { default: header },
  children: [
    new Paragraph({ children: [run("Contents", { bold: true, size: 44 })], spacing: { after: 300 } }),
    ...C.sections.map(s => tocEntry(s.heading, pagenums[s.heading] || "00"))
  ]
};

const bodyChildren = [];
C.sections.forEach(s => {
  bodyChildren.push(heading(s.heading));
  s.paragraphs.forEach(p => bodyChildren.push(body(p)));
});
bodyChildren.push(heading("Closing"));
C.closing.forEach(p => bodyChildren.push(body(p)));

const doc = new Document({
  sections: [titleSection, tocSection, { properties: { page }, headers: { default: header }, children: bodyChildren }]
});

Packer.toBuffer(doc).then(buf => { fs.writeFileSync(outPath, buf); console.log("Wrote", outPath); });
