"""
Title: Haligric confirming-round engine
Author: Claude
Date: 2026-11-10
Modified By: Claude, 2026-11-10
Description: Runs the series' 8-category confirming rounds through the Anthropic API.
             Each category gets live web searches. New, verifiable, in-scope finds are
             added to content.js. Rounds repeat until one full pass finds nothing new.
"""
import datetime, json, os, re, shutil, subprocess, time

CATEGORIES = [
    "Origin and founding",
    "Key figures and texts",
    "Ceremonies and step-by-step rituals",
    "Theology and sacred belief",
    "Self-care, wellness, and daily practice",
    "Wider cosmology, pantheon, spirits, and institutions",
    "Legacy and influence",
    "Controversies and fairness, including recent news",
]

# WHY: these rules mirror the project's inclusion bar, so the API applies the same
# standard used in chat sessions instead of inventing its own.
SYSTEM = """You are the research assistant for the Haligric Research Integration Series, \
deep-dive documents on world sacred traditions. You run one category of a confirming round.

Rules:
- Run at least two real web searches for the category. Fetch a page before you rely on it.
- Only propose material that is verifiable from a page you actually read, specific to this \
tradition, in scope, and NOT already in the document (check carefully, including paraphrases).
- Highest value: rituals (written as numbered steps: "Step one: ..."), beliefs, deities and \
spirits, self-care practices, and recent developments.
- Skip heavy statistics, trivia, and material that belongs to a different tradition.
- Write each addition as one plain paragraph in the document's voice: clear, factual, no hype, \
no claims beyond the source. Keep straight quotes; write names and dates exactly.
- Choose the existing section heading that fits best, copied exactly.

Finish with ONLY a JSON object, no other text after it:
{"additions": [{"section": "<exact existing heading>", "paragraph": "<text>", \
"source_url": "<url you read>", "what": "<5-10 word label>"}], \
"checked": "<one line: what you searched and found already covered>"}
Return {"additions": [], ...} if nothing new and verifiable turned up."""

TOOLS = [
    {"type": "web_search_20250305", "name": "web_search", "max_uses": 6},
    {"type": "web_fetch_20250910", "name": "web_fetch", "max_uses": 6},
]


def load_content(path):
    # WHY: content.js is a Node module, so Node itself is the safest parser for it.
    out = subprocess.run(["node", "-e", f"console.log(JSON.stringify(require({json.dumps(os.path.abspath(path))})))"],
                         check=True, capture_output=True, text=True).stdout
    return json.loads(out)


def save_content(path, data):
    # WHY: keep a backup before every write so a bad round can be rolled back by hand.
    if os.path.exists(path):
        shutil.copyfile(path, path + ".bak")
    with open(path, "w", encoding="utf-8") as f:
        f.write("module.exports = " + json.dumps(data, ensure_ascii=False, indent=2) + ";\n")
    load_content(path)  # WHY: fail loudly now rather than at build time if the file broke


def doc_text(data):
    parts = [f"TRADITION: {data['tradition']}", f"SUBTITLE: {data['subtitle']}"]
    for s in data["sections"]:
        parts.append(f"\n## {s['heading']}")
        parts.extend(s["paragraphs"])
    parts.append("\n## Closing")
    parts.extend(data.get("closing", []))
    return "\n".join(parts)


def ask(client, model, data, category, log):
    import anthropic  # WHY: imported here so PDF conversion works without the API library
    doc = doc_text(data)
    headings = "\n".join(s["heading"] for s in data["sections"])
    # WHY: the document is identical for all 8 calls in a round, so caching it cuts cost a lot.
    messages = [{"role": "user", "content": [
        {"type": "text", "text": "CURRENT DOCUMENT:\n" + doc, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": f"Category for this pass: {category}\n\nToday is "
                                 f"{datetime.date.today().isoformat()}.\n\nExisting section headings:\n{headings}"},
    ]}]
    searches, content = [], []
    for attempt in range(6):
        try:
            resp = client.messages.create(model=model, max_tokens=8000, system=SYSTEM,
                                          tools=TOOLS, messages=messages)
        except anthropic.RateLimitError:
            # WHY: long runs hit per-minute limits; waiting is cheaper than failing the round.
            log("  rate limited, waiting 60s")
            time.sleep(60)
            continue
        content.extend(resp.content)
        for b in resp.content:
            if b.type == "server_tool_use" and b.name == "web_search":
                searches.append(b.input.get("query", ""))
        # WHY: the API pauses long server-side tool loops; resend the content to continue.
        if resp.stop_reason == "pause_turn":
            messages.append({"role": "assistant", "content": resp.content})
            continue
        break
    text = "".join(b.text for b in content if b.type == "text")
    match = re.search(r"\{\s*\"additions\".*\}", text, re.S)
    try:
        result = json.loads(match.group(0)) if match else {"additions": []}
    except json.JSONDecodeError:
        result = {"additions": []}
        log("  could not read the reply as JSON; treated as nothing new")
    return result, searches


def run_round(client, model, path, round_no, log):
    data = load_content(path)
    heads = {s["heading"]: s for s in data["sections"]}
    added = []
    for cat in CATEGORIES:
        result, searches = ask(client, model, data, cat, log)
        if not searches:
            # WHY: the series rule says "already covered" only counts after a real search.
            log(f"  {cat}: no search ran, retrying once")
            result, searches = ask(client, model, data, cat, log)
        log(f"  {cat}: {len(searches)} searches ({'; '.join(searches[:4])})")
        for a in result.get("additions", []):
            para, sec = (a.get("paragraph") or "").strip(), a.get("section")
            if not para or not a.get("source_url"):
                continue
            if sec not in heads:
                log(f"    skipped (unknown section '{sec}'): {a.get('what')}")
                continue
            if para[:60] in doc_text(data):
                continue  # WHY: two categories sometimes find the same item in one round
            heads[sec]["paragraphs"].append(para)
            added.append(a)
            log(f"    ADDED to '{sec}': {a.get('what')} <{a['source_url']}>")
        if not result.get("additions"):
            log(f"    nothing new. {result.get('checked', '')}")
    if added:
        save_content(path, data)
    return added
