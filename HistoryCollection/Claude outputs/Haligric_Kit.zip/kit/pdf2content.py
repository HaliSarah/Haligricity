"""
Title: Haligric PDF-to-content converter
Author: Claude
Date: 2026-11-10
Modified By: Claude, 2026-11-10
Description: Rebuilds an editable content.js from a finished series PDF, so a document can be
             researched and rebuilt even when only the PDF survives.
Usage: python3 pdf2content.py Some_master.pdf out/content.js
"""
import re, statistics, sys

from pypdf import PdfReader

SERIES = "Haligric Research Integration Series"
LEADER = re.compile(r"^(.*?)\s*\.{3,}\s*(\d+)\s*$")
END = re.compile(r"[.!?\"'”’):]$")


def clean_heading(h):
    # WHY: older PDFs numbered their sections ("1.", "Part Seven —"); the series no longer does.
    h = re.sub(r"^(\d+[.)]\s+|Part\s+[A-Z][a-z-]+(\s+[A-Z][a-z-]+)?\s*[—:-]\s*)", "", h.strip())
    return re.sub(r"\s+", " ", h)


def norm(s):
    return re.sub(r"\s+", " ", s.replace("’", "'").replace("“", '"').replace("”", '"')).strip().lower()


def extract(pdf_path):
    reader = PdfReader(pdf_path)
    pages = [(p.extract_text(extraction_mode="layout") or "") for p in reader.pages]
    if sum(len(p.strip()) for p in pages) < 500:
        # WHY: the old image-only PDFs hold pictures of text, which can't be read without OCR.
        raise SystemExit(f"{pdf_path} has no readable text (image-only). Get its source from the project instead.")

    # Title page: series line, title lines, the DEEP DIVE line, subtitle, then the blurb.
    first = [l.strip() for l in pages[0].split("\n")]
    lines = [l for l in first if l]
    lines = [l for l in lines if l != SERIES]
    i = next((k for k, l in enumerate(lines) if "COMPLETE DEEP DIVE" in l.upper()), 1)
    # WHY: the big title wraps on its own, so store it as one line and let the build re-wrap it.
    title_lines = [" ".join(lines[:i])] if i else ["Untitled"]
    rest = "\n".join(first).split("COMPLETE DEEP DIVE", 1)[-1]
    chunks = [re.sub(r"\s+", " ", c).strip() for c in re.split(r"\n\s*\n", rest) if c.strip()]
    subtitle = chunks[0] if chunks else ""
    blurb = chunks[1:] or [""]

    # Contents: every dotted line is a section heading, in order.
    toc, body_start = [], 1
    for n, page in enumerate(pages[1:6], start=1):
        hits = [LEADER.match(re.sub(r"\s+", " ", l.strip())) for l in page.split("\n")]
        hits = [h for h in hits if h]
        if hits:
            toc += [clean_heading(h.group(1)) for h in hits]
            body_start = n + 1
        elif toc:
            break
    if not toc:
        raise SystemExit("No contents page with dotted entries found; this PDF isn't in the series format.")

    # Body: drop the running header, then split on headings and paragraph breaks.
    header_line = None
    raw = []
    for page in pages[body_start:]:
        ls = page.split("\n")
        if ls and SERIES in ls[0]:
            header_line = header_line or ls[0].strip()
            ls = ls[1:]
        raw.append(ls)
        raw.append(["<PAGE>"])
    widths = [len(l.strip()) for ls in raw for l in ls if len(l.strip()) > 40]
    full = statistics.median(widths) if widths else 90

    keys = {norm(h): h for h in toc + ["Closing"]}
    sections, current, para = [], None, []

    def flush():
        if para and current is not None:
            current["paragraphs"].append(" ".join(para))
        para.clear()

    prev, held = "", ""
    flat = [re.sub(r"\s+", " ", l.strip()) for ls in raw for l in ls]
    for idx, s in enumerate(flat):
            if s == "<PAGE>":
                continue  # WHY: paragraphs run across pages, so a page break isn't a paragraph break
            if held:
                # WHY: a long heading can wrap onto two or three lines; rejoin before matching.
                s, held = held + " " + s, ""
            if s and norm(s) not in keys and len(s) > 15 and any(k.startswith(norm(s) + " ") for k in keys):
                held = s
                continue
            if not s:
                flush()
                continue
            if norm(s) in keys:
                flush()
                current = {"heading": keys[norm(s)], "paragraphs": []}
                sections.append(current)
                prev = ""
                continue
            # WHY: justified lines fill the width; a short line ending a sentence closes a paragraph
            # even when the PDF left no blank line after it.
            if prev and len(prev) < 0.8 * full and END.search(prev):
                flush()
            para.append(s)
            prev = s
    flush()

    closing = []
    if sections and sections[-1]["heading"] == "Closing":
        closing = sections.pop()["paragraphs"]
    tradition = header_line.split("|")[0].strip() if header_line and "|" in header_line else " ".join(title_lines)
    missing = [h for h in toc if h not in [s["heading"] for s in sections]]
    if missing:
        print("WARNING: headings listed in Contents but not found in the body:", missing)
    return {"tradition": tradition, "series": SERIES, "titleLines": title_lines, "subtitle": subtitle,
            "blurb": blurb, "sections": sections, "closing": closing}


if __name__ == "__main__":
    from research import save_content
    save_content(sys.argv[2], extract(sys.argv[1]))
    print("Wrote", sys.argv[2])
