"""
Title: Haligric one-command runner
Author: Claude
Date: 2026-11-10
Modified By: Claude, 2026-11-10
Description: Takes a PDF name from the HistoryCollection folder, pulls its text (or the saved
             in-progress source), runs confirming rounds until one comes back clean, then
             rebuilds the PDF and saves it back over the original (or into new/).
Usage:  python3 haligric.py Arctic_Inuit_master.pdf
        python3 haligric.py Some_master.pdf --new          (save to HistoryCollection/new)
        python3 haligric.py Some_master.pdf --build-only   (no research, just rebuild)
Options: --max-rounds N (default 30)   --model NAME (default claude-sonnet-5-5)
"""
import argparse, datetime, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
HISTORY = os.path.expanduser("~/Desktop/Websites/Haligricity/Hosted/HistoryCollection")
sys.path.insert(0, HERE)

p = argparse.ArgumentParser()
p.add_argument("pdf")
p.add_argument("--new", action="store_true")
p.add_argument("--build-only", action="store_true")
p.add_argument("--max-rounds", type=int, default=30)
p.add_argument("--model", default="claude-sonnet-5-5")
args = p.parse_args()

name = os.path.basename(args.pdf)
slug = re.sub(r"_master\.pdf$|\.pdf$", "", name, flags=re.I).lower()
folder = os.path.join(HERE, "sources", slug)
content = os.path.join(folder, "content.js")
state_path = os.path.join(folder, "state.json")
# WHY: logs go in Haligricity/Logs (outside the live Hosted site) so they're easy to find
# and never get published; fall back to the source folder on a computer without it.
LOGS = os.path.expanduser("~/Desktop/Websites/Haligricity/Logs")
if os.path.isdir(os.path.dirname(LOGS)):
    os.makedirs(LOGS, exist_ok=True)
    log_path = os.path.join(LOGS, re.sub(r"\.pdf$", "", name, flags=re.I) + "_Research_Log.md")
    seed = os.path.join(folder, "research_log.md")
    if os.path.exists(seed) and not os.path.exists(log_path):
        shutil.copyfile(seed, log_path)  # WHY: carry over notes that shipped with the kit (Arctic)
else:
    log_path = os.path.join(folder, "research_log.md")
os.makedirs(folder, exist_ok=True)


def log(msg):
    # WHY: the log file is the research record Hali can read later; the screen shows progress.
    print(msg, flush=True)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


# Step 1: get the editable text.
if not os.path.exists(content):
    # WHY: look in new/ too, since brand-new traditions live there until they go live.
    original = next((c for c in [os.path.join(HISTORY, name), os.path.join(HISTORY, "new", name), args.pdf]
                     if os.path.exists(c)), None)
    if not original:
        sys.exit(f"Can't find {name} in {HISTORY} or its new/ folder.")
    from pdf2content import extract
    from research import save_content
    save_content(content, extract(original))
    log(f"# {name}\n\nPulled text from {original} on {datetime.date.today()}.")

from research import load_content, save_content

data = load_content(content)
# WHY: every PDF in the series must close with this line, whatever the old version said.
# WHY: keep the old farewell's meaning ("Grand rising to X" becomes "To X") instead of deleting it.
closing = [re.sub(r"(?i)^grand rising\s+to\s+", "To ", c) for c in data.get("closing", [])]
closing = [re.sub(r"(?i)\bgrand rising\b[,.!]?\s*", "", c).strip() for c in closing]
closing = [c for c in closing if c]
if not closing or not closing[-1].strip().endswith("You are the current."):
    closing.append("You are the current.")
data["closing"] = closing
save_content(content, data)

# Step 2: confirming rounds.
state = json.load(open(state_path)) if os.path.exists(state_path) else {"round": 0, "clean": False}
if not args.build_only and not state.get("clean"):
    # WHY: a key file beside the script saves typing the key into Terminal every session.
    key_file = os.path.join(HERE, "api_key.txt")
    if not os.environ.get("ANTHROPIC_API_KEY") and os.path.exists(key_file):
        os.environ["ANTHROPIC_API_KEY"] = open(key_file).read().strip()
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("No API key. Paste it into api_key.txt in this folder (get one at console.anthropic.com).")
    import anthropic
    from research import run_round
    client = anthropic.Anthropic()
    for _ in range(args.max_rounds):
        state["round"] += 1
        log(f"\n## Round {state['round']} ({datetime.date.today()})")
        added = run_round(client, args.model, content, state["round"], log)
        json.dump(state, open(state_path, "w"))
        if not added:
            state["clean"] = True
            json.dump(state, open(state_path, "w"))
            log(f"\nRound {state['round']} was clean: all 8 categories searched, nothing new. Confirming round complete.")
            break
        log(f"  Round {state['round']} added {len(added)}. Running another full round.")
    else:
        log(f"\nStopped after {args.max_rounds} rounds without a clean pass. Run again to continue.")
elif state.get("clean"):
    print("Already has a clean confirming round. Rebuilding only.")

# Step 3: build and save.
draft = not state.get("clean") and not args.build_only
cmd = [sys.executable, os.path.join(HERE, "twopass.py"), folder, name]
cmd += ["--new"] if args.new else []
cmd += ["--draft"] if draft else []
subprocess.run(cmd, check=True)
if draft:
    print("NOTE: still a draft (no clean round yet), so it was saved in", folder, "and NOT over your original.")
