# Haligric Kit

One command takes a PDF from your HistoryCollection folder and does the rest:

1. Pulls its text from the PDF.
2. Runs 8-category confirming rounds with live web searches, adding anything new and verifiable.
3. Repeats until a full round comes back clean.
4. Rebuilds the PDF with the dot-leader contents page, ending on "You are the current."
5. Saves it back over the original.

Arctic is already loaded where I left off, so it redoes round 26 (cut off midway) and keeps going.

## One-time setup

1. Install **Node.js** (LTS) from nodejs.org.
2. Install **LibreOffice** from libreoffice.org.
3. Get an API key at console.anthropic.com, then paste it into a new file named `api_key.txt` in this folder.
4. Open Terminal, `cd` into this folder, and run:

```
npm install
pip3 install pypdf anthropic
```

## Run it

```
python3 haligric.py Arctic_Inuit_master.pdf
python3 haligric.py Pacific_Northwest_Coast_master.pdf
```

Use the file name exactly as it appears in HistoryCollection. Then leave it running.

- **Finished (clean round):** the PDF overwrites the same file in HistoryCollection.
- **Brand-new tradition:** add `--new` to save it in HistoryCollection/new instead.
- **Not finished yet:** if it stops at the 30-round limit, the draft stays in `sources/<name>/` and your original is left untouched. Run the same command again to continue.
- **Just rebuild, no research:** add `--build-only`.

## What it keeps

Each tradition gets its own folder, `sources/<name>/`, holding:
- `content.js`: the editable text.
- `state.json`: which round it's on.

Research logs go to `~/Desktop/Websites/Haligricity/Logs/<Name>_Research_Log.md`: every round, every search, and every addition with its source link.

## Cost

Research is billed to your API account, roughly cents to a couple of dollars per round depending on the document's length. Watch it at console.anthropic.com. To spend less, add `--max-rounds 5`.

## Limits

- The old image-only PDFs (the July batch, e.g. Hoodoo's first version) have no readable text. Those need their source pulled from the project instead.
- Read the log before publishing. It adds only what it can source, but a human check is still worth it.
